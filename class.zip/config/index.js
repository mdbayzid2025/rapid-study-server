const UPLOAD_USER_IMG_DIRECTORY = "public/upload/users";
const MAX_FILE_SIZE = 104857600; // 100MB in bytes
const ALLOW_FILE_TYPES = ['jpg', "jpeg", "png", 'pdf', 'PDF']
const jwt_access_secret = process.env.jwt_access_secret;

module.exports = {
    UPLOAD_USER_IMG_DIRECTORY,
    MAX_FILE_SIZE,
    ALLOW_FILE_TYPES,
    jwt_access_secret
}

/* env 

MONGO_URL = mongodb+srv://ssmdbayzid23:uYmWXBF57f9HHwro@cluster0.nvuq86p.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0

port = 5000
user = ssmdbayzid23
db_password =  uYmWXBF57f9HHwro
ORIGIN = http://localhost:3000
BASE_URL = http://localhost:5000

CLOUDINARY_CLOUD_NAME = detjedqvq 

CLOUDINARY_API_KEY = 952383858859415

CLOUDINARY_SECRET_KEY = tR2hJQxUnXAibVDVP2eBtjbZCFk

------------------------- Sep 25 ---------------

MONGO_URL = mongodb+srv://ssmdbayzid23:uYmWXBF57f9HHwro@cluster0.nvuq86p.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0

port = 5000
user = ssmdbayzid23
db_password =  uYmWXBF57f9HHwro
ORIGIN = http://localhost:3000
BASE_URL = http://localhost:5000

CLOUDINARY_CLOUD_NAME = detjedqvq 

CLOUDINARY_API_KEY = 952383858859415

CLOUDINARY_SECRET_KEY = tR2hJQxUnXAibVDVP2eBtjbZCFk



*/