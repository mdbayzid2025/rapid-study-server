
export const AddCalanderSchedule = async (data) =>{ 
    try {
       
       console.log("calander", res);               
    } catch (error) {
        console.log("calander error", error);        
    }
}